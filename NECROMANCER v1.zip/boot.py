print("BOOTING")

print("NECROMANCER BOOT MGR")

debug=False

if debug:
    inp = input("Boot? press enter\n\n\n\n")

else: inp = False

if inp != False:
    Boot = 1

else:
    Boot = 0

print(Boot)
